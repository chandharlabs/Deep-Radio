#!/usr/bin/env python2
# -*- coding: utf-8 -*-
##################################################
# GNU Radio Python Flow Graph
# Title: QPSK Transmitter with differential coding
# Author: Manolis Bozis
# GNU Radio version: 3.7.13.5
##################################################

if __name__ == '__main__':
    import ctypes
    import sys
    if sys.platform.startswith('linux'):
        try:
            x11 = ctypes.cdll.LoadLibrary('libX11.so')
            x11.XInitThreads()
        except:
            print "Warning: failed to XInitThreads()"

from PyQt4 import Qt
from gnuradio import blocks
from gnuradio import channels
from gnuradio import digital
from gnuradio import eng_notation
from gnuradio import filter
from gnuradio import gr
from gnuradio import qtgui
from gnuradio.eng_option import eng_option
from gnuradio.filter import firdes
from gnuradio.qtgui import Range, RangeWidget
from optparse import OptionParser
import epy_module_0  # embedded python module
import epy_module_1  # embedded python module
import math
import numpy
import pmt
import sip
import sys
from gnuradio import qtgui


class QPSK_transmitter(gr.top_block, Qt.QWidget):

    def __init__(self):
        gr.top_block.__init__(self, "QPSK Transmitter with differential coding")
        Qt.QWidget.__init__(self)
        self.setWindowTitle("QPSK Transmitter with differential coding")
        qtgui.util.check_set_qss()
        try:
            self.setWindowIcon(Qt.QIcon.fromTheme('gnuradio-grc'))
        except:
            pass
        self.top_scroll_layout = Qt.QVBoxLayout()
        self.setLayout(self.top_scroll_layout)
        self.top_scroll = Qt.QScrollArea()
        self.top_scroll.setFrameStyle(Qt.QFrame.NoFrame)
        self.top_scroll_layout.addWidget(self.top_scroll)
        self.top_scroll.setWidgetResizable(True)
        self.top_widget = Qt.QWidget()
        self.top_scroll.setWidget(self.top_widget)
        self.top_layout = Qt.QVBoxLayout(self.top_widget)
        self.top_grid_layout = Qt.QGridLayout()
        self.top_layout.addLayout(self.top_grid_layout)

        self.settings = Qt.QSettings("GNU Radio", "QPSK_transmitter")
        self.restoreGeometry(self.settings.value("geometry").toByteArray())


        ##################################################
        # Variables
        ##################################################
        self.Taps_No = Taps_No = 31
        self.Mod_Ind = Mod_Ind = 4
        self.sps = sps = 4
        self.Symbol_Map = Symbol_Map = epy_module_1.gray2int( int( math.log(Mod_Ind, 2.0) ) )
        self.Rs = Rs = 1e6
        self.Delay = Delay = int((Taps_No-1)/2)
        self.Const_Pnts = Const_Pnts = epy_module_0.PSKsymbols(Mod_Ind)

        self.var_const = var_const = digital.constellation_calcdist((Const_Pnts), (Symbol_Map), Mod_Ind, 1).base()

        self.timing_offset = timing_offset = 1.0
        self.samp_rate = samp_rate = Rs*sps
        self.noise = noise = 0.0
        self.message_bytes = message_bytes = 44153
        self.frequency_offset = frequency_offset = 0.0
        self.alpha = alpha = 0.35
        self.RC_Delay = RC_Delay = sps-(2*Delay+1)%sps
        self.Points = Points = 10
        self.Carrier_Frequency = Carrier_Frequency = 735e6

        ##################################################
        # Blocks
        ##################################################
        self._timing_offset_range = Range(1.0, 1.001, 1e-6, 1.0, 200)
        self._timing_offset_win = RangeWidget(self._timing_offset_range, self.set_timing_offset, 'timing offset', "counter_slider", float)
        self.top_grid_layout.addWidget(self._timing_offset_win)
        self._noise_range = Range(0.0, 0.2, 0.005, 0.0, 200)
        self._noise_win = RangeWidget(self._noise_range, self.set_noise, 'Noise Voltage', "counter_slider", float)
        self.top_grid_layout.addWidget(self._noise_win)
        self._frequency_offset_range = Range(0.0, 1e-5, 10e-9, 0.0, 200)
        self._frequency_offset_win = RangeWidget(self._frequency_offset_range, self.set_frequency_offset, 'frequency_offset', "counter_slider", float)
        self.top_grid_layout.addWidget(self._frequency_offset_win)
        self.root_raised_cosine_filter_0 = filter.interp_fir_filter_ccf(sps, firdes.root_raised_cosine(
        	1, Rs*sps, Rs, alpha, Taps_No))
        self.qtgui_time_sink_x_0_0 = qtgui.time_sink_c(
        	sps*Points, #size
        	samp_rate, #samp_rate
        	"", #name
        	1 #number of inputs
        )
        self.qtgui_time_sink_x_0_0.set_update_time(0.10)
        self.qtgui_time_sink_x_0_0.set_y_axis(-1, 1)

        self.qtgui_time_sink_x_0_0.set_y_label('Amplitude', "")

        self.qtgui_time_sink_x_0_0.enable_tags(-1, True)
        self.qtgui_time_sink_x_0_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, 0, "")
        self.qtgui_time_sink_x_0_0.enable_autoscale(False)
        self.qtgui_time_sink_x_0_0.enable_grid(False)
        self.qtgui_time_sink_x_0_0.enable_axis_labels(True)
        self.qtgui_time_sink_x_0_0.enable_control_panel(False)
        self.qtgui_time_sink_x_0_0.enable_stem_plot(False)

        if not True:
          self.qtgui_time_sink_x_0_0.disable_legend()

        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
                  "magenta", "yellow", "dark red", "dark green", "blue"]
        styles = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
                   -1, -1, -1, -1, -1]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]

        for i in xrange(2):
            if len(labels[i]) == 0:
                if(i % 2 == 0):
                    self.qtgui_time_sink_x_0_0.set_line_label(i, "Re{{Data {0}}}".format(i/2))
                else:
                    self.qtgui_time_sink_x_0_0.set_line_label(i, "Im{{Data {0}}}".format(i/2))
            else:
                self.qtgui_time_sink_x_0_0.set_line_label(i, labels[i])
            self.qtgui_time_sink_x_0_0.set_line_width(i, widths[i])
            self.qtgui_time_sink_x_0_0.set_line_color(i, colors[i])
            self.qtgui_time_sink_x_0_0.set_line_style(i, styles[i])
            self.qtgui_time_sink_x_0_0.set_line_marker(i, markers[i])
            self.qtgui_time_sink_x_0_0.set_line_alpha(i, alphas[i])

        self._qtgui_time_sink_x_0_0_win = sip.wrapinstance(self.qtgui_time_sink_x_0_0.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_time_sink_x_0_0_win)
        self.qtgui_freq_sink_x_0 = qtgui.freq_sink_c(
        	1024, #size
        	firdes.WIN_BLACKMAN_hARRIS, #wintype
        	0, #fc
        	float(samp_rate*sps), #bw
        	"", #name
        	1 #number of inputs
        )
        self.qtgui_freq_sink_x_0.set_update_time(0.10)
        self.qtgui_freq_sink_x_0.set_y_axis(-140, 10)
        self.qtgui_freq_sink_x_0.set_y_label('Relative Gain', 'dB')
        self.qtgui_freq_sink_x_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, 0.0, 0, "")
        self.qtgui_freq_sink_x_0.enable_autoscale(False)
        self.qtgui_freq_sink_x_0.enable_grid(False)
        self.qtgui_freq_sink_x_0.set_fft_average(1.0)
        self.qtgui_freq_sink_x_0.enable_axis_labels(True)
        self.qtgui_freq_sink_x_0.enable_control_panel(False)

        if not True:
          self.qtgui_freq_sink_x_0.disable_legend()

        if "complex" == "float" or "complex" == "msg_float":
          self.qtgui_freq_sink_x_0.set_plot_pos_half(not True)

        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
                  "magenta", "yellow", "dark red", "dark green", "dark blue"]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]
        for i in xrange(1):
            if len(labels[i]) == 0:
                self.qtgui_freq_sink_x_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_freq_sink_x_0.set_line_label(i, labels[i])
            self.qtgui_freq_sink_x_0.set_line_width(i, widths[i])
            self.qtgui_freq_sink_x_0.set_line_color(i, colors[i])
            self.qtgui_freq_sink_x_0.set_line_alpha(i, alphas[i])

        self._qtgui_freq_sink_x_0_win = sip.wrapinstance(self.qtgui_freq_sink_x_0.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_freq_sink_x_0_win)
        self.qtgui_const_sink_x_0 = qtgui.const_sink_c(
        	1024, #size
        	"QPSK Constellation", #name
        	1 #number of inputs
        )
        self.qtgui_const_sink_x_0.set_update_time(0.10)
        self.qtgui_const_sink_x_0.set_y_axis(-2, 2)
        self.qtgui_const_sink_x_0.set_x_axis(-2, 2)
        self.qtgui_const_sink_x_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.qtgui_const_sink_x_0.enable_autoscale(False)
        self.qtgui_const_sink_x_0.enable_grid(False)
        self.qtgui_const_sink_x_0.enable_axis_labels(True)

        if not True:
          self.qtgui_const_sink_x_0.disable_legend()

        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "red", "red", "red",
                  "red", "red", "red", "red", "red"]
        styles = [0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]
        for i in xrange(1):
            if len(labels[i]) == 0:
                self.qtgui_const_sink_x_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_const_sink_x_0.set_line_label(i, labels[i])
            self.qtgui_const_sink_x_0.set_line_width(i, widths[i])
            self.qtgui_const_sink_x_0.set_line_color(i, colors[i])
            self.qtgui_const_sink_x_0.set_line_style(i, styles[i])
            self.qtgui_const_sink_x_0.set_line_marker(i, markers[i])
            self.qtgui_const_sink_x_0.set_line_alpha(i, alphas[i])

        self._qtgui_const_sink_x_0_win = sip.wrapinstance(self.qtgui_const_sink_x_0.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_const_sink_x_0_win)
        self.digital_diff_encoder_bb_0 = digital.diff_encoder_bb(Mod_Ind)
        self.digital_chunks_to_symbols_xx_0 = digital.chunks_to_symbols_bc((Const_Pnts), 1)
        self.channels_channel_model_0 = channels.channel_model(
        	noise_voltage=noise,
        	frequency_offset=frequency_offset,
        	epsilon=timing_offset,
        	taps=(1.0, ),
        	noise_seed=0,
        	block_tags=False
        )
        self.blocks_udp_sink_0 = blocks.udp_sink(gr.sizeof_gr_complex*1, '192.168.0.4', 1200, 8192, True)
        self.blocks_throttle_0 = blocks.throttle(gr.sizeof_gr_complex*1, samp_rate,True)
        self.blocks_stream_mux_0 = blocks.stream_mux(gr.sizeof_char*1, (2, 44153))
        self.blocks_packed_to_unpacked_xx_0 = blocks.packed_to_unpacked_bb(int(math.log(Mod_Ind, 2)), gr.GR_MSB_FIRST)
        self.blocks_multiply_const_vxx_0_1 = blocks.multiply_const_vcc((1, ))
        self.blocks_file_source_0_0 = blocks.file_source(gr.sizeof_char*1, 'D:\\scripts\\grc\\BPSK\\transmitter\\TXT_send.txt', True)
        self.blocks_file_source_0_0.set_begin_tag(pmt.PMT_NIL)
        self.blocks_file_source_0 = blocks.file_source(gr.sizeof_char*1, 'D:\\scripts\\grc\\BPSK\\transmitter\\preample.hex', True)
        self.blocks_file_source_0.set_begin_tag(pmt.PMT_NIL)



        ##################################################
        # Connections
        ##################################################
        self.connect((self.blocks_file_source_0, 0), (self.blocks_stream_mux_0, 0))
        self.connect((self.blocks_file_source_0_0, 0), (self.blocks_stream_mux_0, 1))
        self.connect((self.blocks_multiply_const_vxx_0_1, 0), (self.blocks_throttle_0, 0))
        self.connect((self.blocks_packed_to_unpacked_xx_0, 0), (self.digital_diff_encoder_bb_0, 0))
        self.connect((self.blocks_stream_mux_0, 0), (self.blocks_packed_to_unpacked_xx_0, 0))
        self.connect((self.blocks_throttle_0, 0), (self.root_raised_cosine_filter_0, 0))
        self.connect((self.channels_channel_model_0, 0), (self.blocks_udp_sink_0, 0))
        self.connect((self.digital_chunks_to_symbols_xx_0, 0), (self.blocks_multiply_const_vxx_0_1, 0))
        self.connect((self.digital_chunks_to_symbols_xx_0, 0), (self.qtgui_const_sink_x_0, 0))
        self.connect((self.digital_diff_encoder_bb_0, 0), (self.digital_chunks_to_symbols_xx_0, 0))
        self.connect((self.root_raised_cosine_filter_0, 0), (self.channels_channel_model_0, 0))
        self.connect((self.root_raised_cosine_filter_0, 0), (self.qtgui_freq_sink_x_0, 0))
        self.connect((self.root_raised_cosine_filter_0, 0), (self.qtgui_time_sink_x_0_0, 0))

    def closeEvent(self, event):
        self.settings = Qt.QSettings("GNU Radio", "QPSK_transmitter")
        self.settings.setValue("geometry", self.saveGeometry())
        event.accept()

    def get_Taps_No(self):
        return self.Taps_No

    def set_Taps_No(self, Taps_No):
        self.Taps_No = Taps_No
        self.root_raised_cosine_filter_0.set_taps(firdes.root_raised_cosine(1, self.Rs*self.sps, self.Rs, self.alpha, self.Taps_No))
        self.set_Delay(int((self.Taps_No-1)/2))

    def get_Mod_Ind(self):
        return self.Mod_Ind

    def set_Mod_Ind(self, Mod_Ind):
        self.Mod_Ind = Mod_Ind
        self.set_Const_Pnts(epy_module_0.PSKsymbols(self.Mod_Ind))
        self.set_Symbol_Map(epy_module_1.gray2int( int( math.log(self.Mod_Ind, 2.0) ) ))

    def get_sps(self):
        return self.sps

    def set_sps(self, sps):
        self.sps = sps
        self.set_samp_rate(self.Rs*self.sps)
        self.root_raised_cosine_filter_0.set_taps(firdes.root_raised_cosine(1, self.Rs*self.sps, self.Rs, self.alpha, self.Taps_No))
        self.qtgui_freq_sink_x_0.set_frequency_range(0, float(self.samp_rate*self.sps))
        self.set_RC_Delay(self.sps-(2*self.Delay+1)%self.sps)

    def get_Symbol_Map(self):
        return self.Symbol_Map

    def set_Symbol_Map(self, Symbol_Map):
        self.Symbol_Map = Symbol_Map

    def get_Rs(self):
        return self.Rs

    def set_Rs(self, Rs):
        self.Rs = Rs
        self.set_samp_rate(self.Rs*self.sps)
        self.root_raised_cosine_filter_0.set_taps(firdes.root_raised_cosine(1, self.Rs*self.sps, self.Rs, self.alpha, self.Taps_No))

    def get_Delay(self):
        return self.Delay

    def set_Delay(self, Delay):
        self.Delay = Delay
        self.set_RC_Delay(self.sps-(2*self.Delay+1)%self.sps)

    def get_Const_Pnts(self):
        return self.Const_Pnts

    def set_Const_Pnts(self, Const_Pnts):
        self.Const_Pnts = Const_Pnts
        self.digital_chunks_to_symbols_xx_0.set_symbol_table((self.Const_Pnts))

    def get_var_const(self):
        return self.var_const

    def set_var_const(self, var_const):
        self.var_const = var_const

    def get_timing_offset(self):
        return self.timing_offset

    def set_timing_offset(self, timing_offset):
        self.timing_offset = timing_offset
        self.channels_channel_model_0.set_timing_offset(self.timing_offset)

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.qtgui_time_sink_x_0_0.set_samp_rate(self.samp_rate)
        self.qtgui_freq_sink_x_0.set_frequency_range(0, float(self.samp_rate*self.sps))
        self.blocks_throttle_0.set_sample_rate(self.samp_rate)

    def get_noise(self):
        return self.noise

    def set_noise(self, noise):
        self.noise = noise
        self.channels_channel_model_0.set_noise_voltage(self.noise)

    def get_message_bytes(self):
        return self.message_bytes

    def set_message_bytes(self, message_bytes):
        self.message_bytes = message_bytes

    def get_frequency_offset(self):
        return self.frequency_offset

    def set_frequency_offset(self, frequency_offset):
        self.frequency_offset = frequency_offset
        self.channels_channel_model_0.set_frequency_offset(self.frequency_offset)

    def get_alpha(self):
        return self.alpha

    def set_alpha(self, alpha):
        self.alpha = alpha
        self.root_raised_cosine_filter_0.set_taps(firdes.root_raised_cosine(1, self.Rs*self.sps, self.Rs, self.alpha, self.Taps_No))

    def get_RC_Delay(self):
        return self.RC_Delay

    def set_RC_Delay(self, RC_Delay):
        self.RC_Delay = RC_Delay

    def get_Points(self):
        return self.Points

    def set_Points(self, Points):
        self.Points = Points

    def get_Carrier_Frequency(self):
        return self.Carrier_Frequency

    def set_Carrier_Frequency(self, Carrier_Frequency):
        self.Carrier_Frequency = Carrier_Frequency


def main(top_block_cls=QPSK_transmitter, options=None):

    from distutils.version import StrictVersion
    if StrictVersion(Qt.qVersion()) >= StrictVersion("4.5.0"):
        style = gr.prefs().get_string('qtgui', 'style', 'raster')
        Qt.QApplication.setGraphicsSystem(style)
    qapp = Qt.QApplication(sys.argv)

    tb = top_block_cls()
    tb.start()
    tb.show()

    def quitting():
        tb.stop()
        tb.wait()
    qapp.connect(qapp, Qt.SIGNAL("aboutToQuit()"), quitting)
    qapp.exec_()


if __name__ == '__main__':
    main()
