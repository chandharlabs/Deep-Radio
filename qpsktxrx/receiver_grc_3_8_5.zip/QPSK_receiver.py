#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Qpsk Receiver
# Author: Manolis Bozis
# Description: QPSK receiver with RTLSDR
# GNU Radio version: v3.8.5.0-5-g982205bd

from distutils.version import StrictVersion

if __name__ == '__main__':
    import ctypes
    import sys
    if sys.platform.startswith('linux'):
        try:
            x11 = ctypes.cdll.LoadLibrary('libX11.so')
            x11.XInitThreads()
        except:
            print("Warning: failed to XInitThreads()")

from PyQt5 import Qt
from gnuradio import eng_notation
from gnuradio import qtgui
from gnuradio.filter import firdes
import sip
from gnuradio import analog
from gnuradio import blocks
from gnuradio import digital
from gnuradio import gr
import sys
import signal
from argparse import ArgumentParser
from gnuradio.eng_arg import eng_float, intx
from gnuradio.qtgui import Range, RangeWidget
import epy_module_0  # embedded python module
import epy_module_1  # embedded python module
import math
import numpy
import osmosdr
import time

from gnuradio import qtgui

class QPSK_receiver(gr.top_block, Qt.QWidget):

    def __init__(self):
        gr.top_block.__init__(self, "Qpsk Receiver")
        Qt.QWidget.__init__(self)
        self.setWindowTitle("Qpsk Receiver")
        qtgui.util.check_set_qss()
        try:
            self.setWindowIcon(Qt.QIcon.fromTheme('gnuradio-grc'))
        except:
            pass
        self.top_scroll_layout = Qt.QVBoxLayout()
        self.setLayout(self.top_scroll_layout)
        self.top_scroll = Qt.QScrollArea()
        self.top_scroll.setFrameStyle(Qt.QFrame.NoFrame)
        self.top_scroll_layout.addWidget(self.top_scroll)
        self.top_scroll.setWidgetResizable(True)
        self.top_widget = Qt.QWidget()
        self.top_scroll.setWidget(self.top_widget)
        self.top_layout = Qt.QVBoxLayout(self.top_widget)
        self.top_grid_layout = Qt.QGridLayout()
        self.top_layout.addLayout(self.top_grid_layout)

        self.settings = Qt.QSettings("GNU Radio", "QPSK_receiver")

        try:
            if StrictVersion(Qt.qVersion()) < StrictVersion("5.0.0"):
                self.restoreGeometry(self.settings.value("geometry").toByteArray())
            else:
                self.restoreGeometry(self.settings.value("geometry"))
        except:
            pass

        ##################################################
        # Variables
        ##################################################
        self.Mod_Ind = Mod_Ind = 4
        self.samp_rate = samp_rate = 2.048e6
        self.alpha = alpha = 0.35
        self.Taps_No = Taps_No = 31
        self.Symbol_Map = Symbol_Map = epy_module_1.gray2int( int( math.log(Mod_Ind, 2.0) ) )
        self.Rs = Rs = 500e3
        self.Const_Pnts = Const_Pnts = epy_module_0.PSKsymbols(Mod_Ind)
        self.timing_loop_bw = timing_loop_bw = 157.079e-3
        self.sps = sps = samp_rate/Rs
        self.rrc_taps = rrc_taps = firdes.root_raised_cosine(1.0, samp_rate, Rs, alpha, Taps_No)
        self.preample_length = preample_length = 2*8
        self.phase_bw = phase_bw = 2*math.pi/100
        self.nfilts = nfilts = 32
        self.message_length = message_length = 44153*8
        self.RRC_Taps = RRC_Taps = firdes.root_raised_cosine(1.0, samp_rate,Rs, alpha, Taps_No)
        self.QPSK = QPSK = digital.constellation_calcdist(Const_Pnts, Symbol_Map,
        Mod_Ind, 1).base()
        self.Points = Points = 10
        self.Carrier_Frequency = Carrier_Frequency = 735e6

        ##################################################
        # Blocks
        ##################################################
        self._timing_loop_bw_range = Range(0, 10, 1e-6, 157.079e-3, 200)
        self._timing_loop_bw_win = RangeWidget(self._timing_loop_bw_range, self.set_timing_loop_bw, 'timing_loop_bw', "counter_slider", float)
        self.top_layout.addWidget(self._timing_loop_bw_win)
        self._phase_bw_range = Range(0, 10, 1e-3, 2*math.pi/100, 200)
        self._phase_bw_win = RangeWidget(self._phase_bw_range, self.set_phase_bw, 'phase_bw', "counter_slider", float)
        self.top_layout.addWidget(self._phase_bw_win)
        self._Mod_Ind_tool_bar = Qt.QToolBar(self)

        if None:
            self._Mod_Ind_formatter = None
        else:
            self._Mod_Ind_formatter = lambda x: str(x)

        self._Mod_Ind_tool_bar.addWidget(Qt.QLabel('Modulation Index' + ": "))
        self._Mod_Ind_label = Qt.QLabel(str(self._Mod_Ind_formatter(self.Mod_Ind)))
        self._Mod_Ind_tool_bar.addWidget(self._Mod_Ind_label)
        self.top_layout.addWidget(self._Mod_Ind_tool_bar)
        self.rtlsdr_source_0 = osmosdr.source(
            args="numchan=" + str(1) + " " + 'rtl=0'
        )
        self.rtlsdr_source_0.set_time_unknown_pps(osmosdr.time_spec_t())
        self.rtlsdr_source_0.set_sample_rate(samp_rate)
        self.rtlsdr_source_0.set_center_freq(Carrier_Frequency, 0)
        self.rtlsdr_source_0.set_freq_corr(0, 0)
        self.rtlsdr_source_0.set_gain(15, 0)
        self.rtlsdr_source_0.set_if_gain(15, 0)
        self.rtlsdr_source_0.set_bb_gain(15, 0)
        self.rtlsdr_source_0.set_antenna('', 0)
        self.rtlsdr_source_0.set_bandwidth(samp_rate, 0)
        self.qtgui_time_sink_x_0_0 = qtgui.time_sink_c(
            int(Points), #size
            samp_rate, #samp_rate
            "", #name
            1 #number of inputs
        )
        self.qtgui_time_sink_x_0_0.set_update_time(0.10)
        self.qtgui_time_sink_x_0_0.set_y_axis(-1, 1)

        self.qtgui_time_sink_x_0_0.set_y_label('Amplitude', "")

        self.qtgui_time_sink_x_0_0.enable_tags(True)
        self.qtgui_time_sink_x_0_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, 0, "")
        self.qtgui_time_sink_x_0_0.enable_autoscale(False)
        self.qtgui_time_sink_x_0_0.enable_grid(False)
        self.qtgui_time_sink_x_0_0.enable_axis_labels(True)
        self.qtgui_time_sink_x_0_0.enable_control_panel(False)
        self.qtgui_time_sink_x_0_0.enable_stem_plot(False)


        labels = ['Signal 1', 'Signal 2', 'Signal 3', 'Signal 4', 'Signal 5',
            'Signal 6', 'Signal 7', 'Signal 8', 'Signal 9', 'Signal 10']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ['blue', 'red', 'green', 'black', 'cyan',
            'magenta', 'yellow', 'dark red', 'dark green', 'dark blue']
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]
        styles = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1]


        for i in range(2):
            if len(labels[i]) == 0:
                if (i % 2 == 0):
                    self.qtgui_time_sink_x_0_0.set_line_label(i, "Re{{Data {0}}}".format(i/2))
                else:
                    self.qtgui_time_sink_x_0_0.set_line_label(i, "Im{{Data {0}}}".format(i/2))
            else:
                self.qtgui_time_sink_x_0_0.set_line_label(i, labels[i])
            self.qtgui_time_sink_x_0_0.set_line_width(i, widths[i])
            self.qtgui_time_sink_x_0_0.set_line_color(i, colors[i])
            self.qtgui_time_sink_x_0_0.set_line_style(i, styles[i])
            self.qtgui_time_sink_x_0_0.set_line_marker(i, markers[i])
            self.qtgui_time_sink_x_0_0.set_line_alpha(i, alphas[i])

        self._qtgui_time_sink_x_0_0_win = sip.wrapinstance(self.qtgui_time_sink_x_0_0.pyqwidget(), Qt.QWidget)
        self.top_layout.addWidget(self._qtgui_time_sink_x_0_0_win)
        self.qtgui_freq_sink_x_0 = qtgui.freq_sink_c(
            1024, #size
            firdes.WIN_BLACKMAN_hARRIS, #wintype
            0, #fc
            samp_rate, #bw
            "", #name
            1
        )
        self.qtgui_freq_sink_x_0.set_update_time(0.10)
        self.qtgui_freq_sink_x_0.set_y_axis(-140, 10)
        self.qtgui_freq_sink_x_0.set_y_label('Relative Gain', 'dB')
        self.qtgui_freq_sink_x_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, 0.0, 0, "")
        self.qtgui_freq_sink_x_0.enable_autoscale(False)
        self.qtgui_freq_sink_x_0.enable_grid(False)
        self.qtgui_freq_sink_x_0.set_fft_average(1.0)
        self.qtgui_freq_sink_x_0.enable_axis_labels(True)
        self.qtgui_freq_sink_x_0.enable_control_panel(False)



        labels = ['', '', '', '', '',
            '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
            "magenta", "yellow", "dark red", "dark green", "dark blue"]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.qtgui_freq_sink_x_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_freq_sink_x_0.set_line_label(i, labels[i])
            self.qtgui_freq_sink_x_0.set_line_width(i, widths[i])
            self.qtgui_freq_sink_x_0.set_line_color(i, colors[i])
            self.qtgui_freq_sink_x_0.set_line_alpha(i, alphas[i])

        self._qtgui_freq_sink_x_0_win = sip.wrapinstance(self.qtgui_freq_sink_x_0.pyqwidget(), Qt.QWidget)
        self.top_layout.addWidget(self._qtgui_freq_sink_x_0_win)
        self.qtgui_const_sink_x_0 = qtgui.const_sink_c(
            100, #size
            'Rx Constellation Diagram Sync', #name
            1 #number of inputs
        )
        self.qtgui_const_sink_x_0.set_update_time(0.10)
        self.qtgui_const_sink_x_0.set_y_axis(-2, 2)
        self.qtgui_const_sink_x_0.set_x_axis(-2, 2)
        self.qtgui_const_sink_x_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.qtgui_const_sink_x_0.enable_autoscale(False)
        self.qtgui_const_sink_x_0.enable_grid(True)
        self.qtgui_const_sink_x_0.enable_axis_labels(True)


        labels = ['', '', '', '', '',
            '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ["blue", "red", "red", "red", "red",
            "red", "red", "red", "red", "red"]
        styles = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.qtgui_const_sink_x_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_const_sink_x_0.set_line_label(i, labels[i])
            self.qtgui_const_sink_x_0.set_line_width(i, widths[i])
            self.qtgui_const_sink_x_0.set_line_color(i, colors[i])
            self.qtgui_const_sink_x_0.set_line_style(i, styles[i])
            self.qtgui_const_sink_x_0.set_line_marker(i, markers[i])
            self.qtgui_const_sink_x_0.set_line_alpha(i, alphas[i])

        self._qtgui_const_sink_x_0_win = sip.wrapinstance(self.qtgui_const_sink_x_0.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_const_sink_x_0_win, 2, 0, 1, 1)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 1):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.digital_pfb_clock_sync_xxx_0 = digital.pfb_clock_sync_ccf(sps, timing_loop_bw, firdes.root_raised_cosine(32,32*sps,1.0,alpha,32*sps*11), 32, 16, 1.5, 1)
        self.digital_diff_decoder_bb_0 = digital.diff_decoder_bb(Mod_Ind)
        self.digital_costas_loop_cc_1 = digital.costas_loop_cc(phase_bw, Mod_Ind, False)
        self.digital_correlate_access_code_bb_0 = digital.correlate_access_code_bb("0101010110101010", 0)
        self.digital_constellation_decoder_cb_0 = digital.constellation_decoder_cb(QPSK)
        self.blocks_unpacked_to_packed_xx_0_0 = blocks.unpacked_to_packed_bb(1, gr.GR_MSB_FIRST)
        self.blocks_tagged_stream_align_0 = blocks.tagged_stream_align(gr.sizeof_char*1, 'burst')
        self.blocks_tag_gate_0 = blocks.tag_gate(gr.sizeof_char * 1, False)
        self.blocks_tag_gate_0.set_single_key("")
        self.blocks_stream_to_streams_0 = blocks.stream_to_streams(gr.sizeof_char*1, 2)
        self.blocks_repack_bits_bb_0_0 = blocks.repack_bits_bb(2, 1, "", False, gr.GR_MSB_FIRST)
        self.blocks_repack_bits_bb_0 = blocks.repack_bits_bb(2, 1, "", False, gr.GR_LSB_FIRST)
        self.blocks_keep_m_in_n_0 = blocks.keep_m_in_n(gr.sizeof_char, message_length, message_length+preample_length, 0)
        self.blocks_file_sink_0_0_1 = blocks.file_sink(gr.sizeof_char*1, '/home/manolis/grc/QPSK/TXTout.txt', False)
        self.blocks_file_sink_0_0_1.set_unbuffered(False)
        self.blocks_char_to_short_0 = blocks.char_to_short(1)
        self.blocks_burst_tagger_0 = blocks.burst_tagger(gr.sizeof_char)
        self.blocks_burst_tagger_0.set_true_tag('burst',True)
        self.blocks_burst_tagger_0.set_false_tag('burst',False)
        self.analog_feedforward_agc_cc_0 = analog.feedforward_agc_cc(20, 2.0)
        self._Taps_No_tool_bar = Qt.QToolBar(self)

        if None:
            self._Taps_No_formatter = None
        else:
            self._Taps_No_formatter = lambda x: str(x)

        self._Taps_No_tool_bar.addWidget(Qt.QLabel('Number of FIR Filter Taps' + ": "))
        self._Taps_No_label = Qt.QLabel(str(self._Taps_No_formatter(self.Taps_No)))
        self._Taps_No_tool_bar.addWidget(self._Taps_No_label)
        self.top_layout.addWidget(self._Taps_No_tool_bar)
        self._Rs_tool_bar = Qt.QToolBar(self)

        if None:
            self._Rs_formatter = None
        else:
            self._Rs_formatter = lambda x: eng_notation.num_to_str(x)

        self._Rs_tool_bar.addWidget(Qt.QLabel('Symbol Rate (symbols per second)' + ": "))
        self._Rs_label = Qt.QLabel(str(self._Rs_formatter(self.Rs)))
        self._Rs_tool_bar.addWidget(self._Rs_label)
        self.top_layout.addWidget(self._Rs_tool_bar)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.analog_feedforward_agc_cc_0, 0), (self.digital_pfb_clock_sync_xxx_0, 0))
        self.connect((self.blocks_burst_tagger_0, 0), (self.blocks_tagged_stream_align_0, 0))
        self.connect((self.blocks_char_to_short_0, 0), (self.blocks_burst_tagger_0, 1))
        self.connect((self.blocks_keep_m_in_n_0, 0), (self.blocks_unpacked_to_packed_xx_0_0, 0))
        self.connect((self.blocks_repack_bits_bb_0, 0), (self.blocks_stream_to_streams_0, 0))
        self.connect((self.blocks_repack_bits_bb_0_0, 0), (self.digital_correlate_access_code_bb_0, 0))
        self.connect((self.blocks_stream_to_streams_0, 0), (self.blocks_burst_tagger_0, 0))
        self.connect((self.blocks_stream_to_streams_0, 1), (self.blocks_char_to_short_0, 0))
        self.connect((self.blocks_tag_gate_0, 0), (self.blocks_keep_m_in_n_0, 0))
        self.connect((self.blocks_tagged_stream_align_0, 0), (self.blocks_tag_gate_0, 0))
        self.connect((self.blocks_unpacked_to_packed_xx_0_0, 0), (self.blocks_file_sink_0_0_1, 0))
        self.connect((self.digital_constellation_decoder_cb_0, 0), (self.digital_diff_decoder_bb_0, 0))
        self.connect((self.digital_correlate_access_code_bb_0, 0), (self.blocks_repack_bits_bb_0, 0))
        self.connect((self.digital_costas_loop_cc_1, 0), (self.digital_constellation_decoder_cb_0, 0))
        self.connect((self.digital_costas_loop_cc_1, 0), (self.qtgui_const_sink_x_0, 0))
        self.connect((self.digital_costas_loop_cc_1, 0), (self.qtgui_time_sink_x_0_0, 0))
        self.connect((self.digital_diff_decoder_bb_0, 0), (self.blocks_repack_bits_bb_0_0, 0))
        self.connect((self.digital_pfb_clock_sync_xxx_0, 0), (self.digital_costas_loop_cc_1, 0))
        self.connect((self.rtlsdr_source_0, 0), (self.analog_feedforward_agc_cc_0, 0))
        self.connect((self.rtlsdr_source_0, 0), (self.qtgui_freq_sink_x_0, 0))


    def closeEvent(self, event):
        self.settings = Qt.QSettings("GNU Radio", "QPSK_receiver")
        self.settings.setValue("geometry", self.saveGeometry())
        event.accept()

    def get_Mod_Ind(self):
        return self.Mod_Ind

    def set_Mod_Ind(self, Mod_Ind):
        self.Mod_Ind = Mod_Ind
        self.set_Const_Pnts(epy_module_0.PSKsymbols(self.Mod_Ind))
        Qt.QMetaObject.invokeMethod(self._Mod_Ind_label, "setText", Qt.Q_ARG("QString", self.Mod_Ind))
        self.set_Symbol_Map(epy_module_1.gray2int( int( math.log(self.Mod_Ind, 2.0) ) ))

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.set_RRC_Taps(firdes.root_raised_cosine(1.0, self.samp_rate, self.Rs, self.alpha, self.Taps_No))
        self.set_rrc_taps(firdes.root_raised_cosine(1.0, self.samp_rate, self.Rs, self.alpha, self.Taps_No))
        self.set_sps(self.samp_rate/self.Rs)
        self.qtgui_freq_sink_x_0.set_frequency_range(0, self.samp_rate)
        self.qtgui_time_sink_x_0_0.set_samp_rate(self.samp_rate)
        self.rtlsdr_source_0.set_sample_rate(self.samp_rate)
        self.rtlsdr_source_0.set_bandwidth(self.samp_rate, 0)

    def get_alpha(self):
        return self.alpha

    def set_alpha(self, alpha):
        self.alpha = alpha
        self.set_RRC_Taps(firdes.root_raised_cosine(1.0, self.samp_rate, self.Rs, self.alpha, self.Taps_No))
        self.set_rrc_taps(firdes.root_raised_cosine(1.0, self.samp_rate, self.Rs, self.alpha, self.Taps_No))
        self.digital_pfb_clock_sync_xxx_0.update_taps(firdes.root_raised_cosine(32,32*self.sps,1.0,self.alpha,32*self.sps*11))

    def get_Taps_No(self):
        return self.Taps_No

    def set_Taps_No(self, Taps_No):
        self.Taps_No = Taps_No
        self.set_RRC_Taps(firdes.root_raised_cosine(1.0, self.samp_rate, self.Rs, self.alpha, self.Taps_No))
        Qt.QMetaObject.invokeMethod(self._Taps_No_label, "setText", Qt.Q_ARG("QString", self.Taps_No))
        self.set_rrc_taps(firdes.root_raised_cosine(1.0, self.samp_rate, self.Rs, self.alpha, self.Taps_No))

    def get_Symbol_Map(self):
        return self.Symbol_Map

    def set_Symbol_Map(self, Symbol_Map):
        self.Symbol_Map = Symbol_Map

    def get_Rs(self):
        return self.Rs

    def set_Rs(self, Rs):
        self.Rs = Rs
        self.set_RRC_Taps(firdes.root_raised_cosine(1.0, self.samp_rate, self.Rs, self.alpha, self.Taps_No))
        Qt.QMetaObject.invokeMethod(self._Rs_label, "setText", Qt.Q_ARG("QString", self.Rs))
        self.set_rrc_taps(firdes.root_raised_cosine(1.0, self.samp_rate, self.Rs, self.alpha, self.Taps_No))
        self.set_sps(self.samp_rate/self.Rs)

    def get_Const_Pnts(self):
        return self.Const_Pnts

    def set_Const_Pnts(self, Const_Pnts):
        self.Const_Pnts = Const_Pnts

    def get_timing_loop_bw(self):
        return self.timing_loop_bw

    def set_timing_loop_bw(self, timing_loop_bw):
        self.timing_loop_bw = timing_loop_bw
        self.digital_pfb_clock_sync_xxx_0.set_loop_bandwidth(self.timing_loop_bw)

    def get_sps(self):
        return self.sps

    def set_sps(self, sps):
        self.sps = sps
        self.digital_pfb_clock_sync_xxx_0.update_taps(firdes.root_raised_cosine(32,32*self.sps,1.0,self.alpha,32*self.sps*11))

    def get_rrc_taps(self):
        return self.rrc_taps

    def set_rrc_taps(self, rrc_taps):
        self.rrc_taps = rrc_taps

    def get_preample_length(self):
        return self.preample_length

    def set_preample_length(self, preample_length):
        self.preample_length = preample_length
        self.blocks_keep_m_in_n_0.set_n(self.message_length+self.preample_length)

    def get_phase_bw(self):
        return self.phase_bw

    def set_phase_bw(self, phase_bw):
        self.phase_bw = phase_bw
        self.digital_costas_loop_cc_1.set_loop_bandwidth(self.phase_bw)

    def get_nfilts(self):
        return self.nfilts

    def set_nfilts(self, nfilts):
        self.nfilts = nfilts

    def get_message_length(self):
        return self.message_length

    def set_message_length(self, message_length):
        self.message_length = message_length
        self.blocks_keep_m_in_n_0.set_m(self.message_length)
        self.blocks_keep_m_in_n_0.set_n(self.message_length+self.preample_length)

    def get_RRC_Taps(self):
        return self.RRC_Taps

    def set_RRC_Taps(self, RRC_Taps):
        self.RRC_Taps = RRC_Taps

    def get_QPSK(self):
        return self.QPSK

    def set_QPSK(self, QPSK):
        self.QPSK = QPSK

    def get_Points(self):
        return self.Points

    def set_Points(self, Points):
        self.Points = Points

    def get_Carrier_Frequency(self):
        return self.Carrier_Frequency

    def set_Carrier_Frequency(self, Carrier_Frequency):
        self.Carrier_Frequency = Carrier_Frequency
        self.rtlsdr_source_0.set_center_freq(self.Carrier_Frequency, 0)





def main(top_block_cls=QPSK_receiver, options=None):

    if StrictVersion("4.5.0") <= StrictVersion(Qt.qVersion()) < StrictVersion("5.0.0"):
        style = gr.prefs().get_string('qtgui', 'style', 'raster')
        Qt.QApplication.setGraphicsSystem(style)
    qapp = Qt.QApplication(sys.argv)

    tb = top_block_cls()

    tb.start()

    tb.show()

    def sig_handler(sig=None, frame=None):
        Qt.QApplication.quit()

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    timer = Qt.QTimer()
    timer.start(500)
    timer.timeout.connect(lambda: None)

    def quitting():
        tb.stop()
        tb.wait()

    qapp.aboutToQuit.connect(quitting)
    qapp.exec_()

if __name__ == '__main__':
    main()
